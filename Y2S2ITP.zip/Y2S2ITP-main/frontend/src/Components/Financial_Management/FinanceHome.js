import React from 'react'
import Navbar from "./NavBarFinance";

function FinanceHome() {
  return (
    <div>
        <Navbar/>
      <h1>This is Financial Analysis Page</h1>
    </div>
  )
}

export default FinanceHome

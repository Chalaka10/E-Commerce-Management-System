
import AdminNav from '../../Components/Nav/adminNav';
import "./dash.css"


function Dashboard() {
  return (
    <div class="flex h-screen overflow-hidden">
      <AdminNav />

      <div class="relative flex flex-1 flex-col overflow-y-auto overflow-x-hidden">
        

        <main>

        </main>
      </div>
    </div>
  );
}

export default Dashboard;
